﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControleDeEstoque.Classe
{
public    class Funcionarios
    {

        #region "Variáveis"

        private int  _id_funcionario;
        private string _nome_funcionario;
        private string _email;
        private string _sobrenome;
        private string _nomeusuario;
        private int _perfil;
        private string _senha;
        private string _frase;
        private int _id_cargo;
        private int _ativo;

        #endregion

        #region "Propriedades"

        public int Id_funcionario
        {
            get { return _id_funcionario; }
            set { _id_funcionario = value; }
        }

        public string Nome_funcionario
        {
            get { return _nome_funcionario; }
            set { _nome_funcionario = value; }
        }

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }

        public string Sobrenome
        {
            get { return _sobrenome; }
            set { _sobrenome = value; }
        }

        public string Nomeusuario
        {
            get { return _nomeusuario; }
            set { _nomeusuario = value; }
        }

        public int Perfil
        {
            get { return _perfil; }
            set { _perfil = value; }
        }
        public string Senha
        {
            get { return _senha; }
            set { _senha = value; }
        }
        public string Frase
        {
            get { return _frase; }
            set { _frase = value; }
        }
        public int Id_cargo
        {
            get { return _id_cargo; }
            set { _id_cargo = value; }
        }
        public int Ativo
        {
            get { return _ativo; }
            set { _ativo = value; }
        }
        #endregion


        #region "Construtores"

        // Construtor padrão
        public Funcionarios()
        {
            Id_funcionario = 0;
            Nome_funcionario = string.Empty;
            Email = string.Empty;
            Nomeusuario = string.Empty;
            Senha = string.Empty;
            Frase = string.Empty;
            Perfil = 0;
            Ativo = 0;
        }

        // Construtor para Efetuar o Login
        public Funcionarios(int id_usuario, string nome_funcionario, string email, string nomeusuario, string senha, string frase, int perfil, int ativo)
        {
            Id_funcionario = id_usuario;
            Nome_funcionario = nome_funcionario;
            Email = email;
            Nomeusuario = nomeusuario;
            Senha = senha;
            Frase = frase;
            Perfil = perfil;
            Ativo = ativo;
        }

        // Construtor para inserir um usuário
        public Funcionarios(string nome,
                      string email,
                      string nomeusuario, 
                      string senha,
                      string frase,
                      int perfil,
                      int ativo)
        {
            Nome_funcionario = nome;
            Email       = email;
            Nomeusuario = nomeusuario;
            Senha       = senha;
            Frase       = frase;
            Perfil      = perfil;
            Ativo       = ativo;
        }

        // Construtor para alterar um usuário
        public Funcionarios(int _id_usuario,
                      string nome_funcionario,
                      string email,
                      string nomeusuario,
                      int perfil)
        {
            Id_funcionario = _id_funcionario;
            Nome_funcionario = nome_funcionario;
            Email = email;
            Nomeusuario = nomeusuario;
            Perfil = perfil;
        }

        // Construtor para alterar a senha de um usuário
        public Funcionarios(int _id_funcionario,
                      string senha,
                      string frase)
        {
            Id_funcionario = _id_funcionario;
            Senha           = senha;
            Frase           = frase;
        }

        // Construtor para Ativar/Desativar um usuário
        public Funcionarios(int _id_funcionario, int ativo)
        {
            Id_funcionario = _id_funcionario;
            Ativo = ativo;
        }

        // Construtor para o DataGrid buscar um usuário
        public Funcionarios(int _id_funcionario)
        {
            Id_funcionario = _id_funcionario;
        }

        #endregion


        #region "Métodos"
        public static void RealizarLogin(string nomeusuario, string senha)
        {
            Conexao cn = new Conexao();
            try
            {
                cn.query = "SELECT * FROM tab_funcionarios WHERE nomeusuario = '" + nomeusuario + "'";
                cn.comando = new MySqlCommand(cn.query, cn.conexao);
                cn.AbreConexao();
                cn.dr = cn.comando.ExecuteReader();
                if (cn.dr.HasRows)
                {
                    Funcionarios funcionarioLogado = new Funcionarios();
                    while (cn.dr.Read())
                    {
                        funcionarioLogado = new Funcionarios(Convert.ToInt32(cn.dr["id_funcionario"]),
                                                cn.dr["nome_funcionario"].ToString(),
                                                cn.dr["email"].ToString(),
                                                cn.dr["nomeusuario"].ToString(),
                                                cn.dr["senha"].ToString(),
                                                cn.dr["frase"].ToString(),
                                                Convert.ToInt32(cn.dr["perfil"]),
                                                Convert.ToInt32(cn.dr["ativo"]));
                    }
                    if (funcionarioLogado.Ativo == 1)
                    {
                        if (funcionarioLogado.Senha == senha)
                        {
                            Telas.FrmPrincipal TP = new Telas.FrmPrincipal(funcionarioLogado);
                            TP.ShowDialog();
                        }
                        else
                        {
                            throw new Exception("Senha inválida!");
                        }
                    }
                    else
                    {
                        throw new Exception("Usuário bloqueado!");
                    }
                }
                else
                {
                    throw new Exception("Usuário não cadastrado!");
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                cn.FechaConexao();
            }
        }

        // Método para inserir um usuário
        public void InsereUsuario()
        {
            Conexao cn = new Conexao();
            try
            {
                cn.query = string.Format("INSERT INTO tab_funcionarios(nome_funcionario, email, sobrenome, nomeusuario, perfil, senha, frase,   ativo) VALUES('{0}', '{1}', '{2}', '{3}', {4}, '{5}', '{6}',{7})" +
                    "", Nome_funcionario, Email, Sobrenome, Nomeusuario, Perfil, Senha, Frase,  Ativo);
                cn.comando = new MySqlCommand(cn.query, cn.conexao);
                cn.AbreConexao();
                cn.comando.ExecuteNonQuery();
                MessageBox.Show("Usuário inserido!", "Cadastro de Usuário", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                cn.FechaConexao();
            }
        }


        // Método para alterar um usuário
        public void AlteraUsuario()
        {
            Conexao cn = new Conexao();
            try
            {
                cn.query = string.Format("UPDATE tab_funcionarios SET nome_funcionario = '{0}', email = '{1}', nomeusuario = '{2}', perfil = '{3}' WHERE id_usuario = {4}", Nome_funcionario, Email, Nomeusuario, Perfil, Id_funcionario);
                cn.comando = new MySqlCommand(cn.query, cn.conexao);
                cn.AbreConexao();
                cn.comando.ExecuteNonQuery();
                MessageBox.Show("Usuário alterado!", "Cadastro de Usuário", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                cn.FechaConexao();
            }
        }


        // Método para alterar a senha de um usuário
        public void AlteraSenha()
        {
            Conexao cn = new Conexao();
            try
            {
                cn.query = string.Format("UPDATE tab_funcionarios SET senha = '{0}', frase = '{1}' WHERE id_funcionario  = {2}", Senha, Frase, Id_funcionario);
                cn.comando = new MySqlCommand(cn.query, cn.conexao);
                cn.AbreConexao();
                cn.comando.ExecuteNonQuery();
                MessageBox.Show("Senha alterada!", "Cadastro de Usuário", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                cn.FechaConexao();
            }
        }


        // Método para Desativar um usuário
        public void DesativaUsuario()
        {
            Conexao cn = new Conexao();
            try
            {
                cn.query = string.Format("UPDATE tab_funcionarios SET ativo = 0 WHERE id_funcionario = {0}", Id_funcionario);
                cn.comando = new MySqlCommand(cn.query, cn.conexao);
                cn.AbreConexao();
                cn.comando.ExecuteNonQuery();
                MessageBox.Show("Usuário desativado!", "Cadastro de Usuário", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                cn.FechaConexao();
            }
        }


        // Método para Ativar um usuário
        public void AtivaUsuario()
        {
            Conexao cn = new Conexao();
            try
            {
                cn.query = string.Format("UPDATE tab_funcionarios SET ativo = 1 WHERE id_funcionario = {0}", Id_funcionario);
                cn.comando = new MySqlCommand(cn.query, cn.conexao);
                cn.AbreConexao();
                cn.comando.ExecuteNonQuery();
                MessageBox.Show("Usuário ativado!", "Cadastro de Usuário", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                cn.FechaConexao();
            }
        }



        // Método para mostrar todos os usuários ativados no DataGrid
        public static dynamic BuscarTodosUsuarios()
        {
            Conexao cn = new Conexao();
            try
            {
                cn.query = "SELECT * FROM tab_funcionarios WHERE ativo = 1";
                cn.da = new MySqlDataAdapter(cn.query, cn.conexao);
                cn.ds = new DataSet();
                cn.da.Fill(cn.ds, "Usuarios");
                return cn.ds.Tables["Usuarios"];
            }
            catch (Exception)
            {

                throw;
            }
        }


        //Método para mostrar todos os usuários desativados no DataGrid
        public static dynamic BuscarTodosUsuariosDesativados()
        {
            Conexao cn = new Conexao();
            try
            {
                cn.query = "SELECT * FROM tab_funcionarios WHERE ativo = 0";
                cn.da = new MySqlDataAdapter(cn.query, cn.conexao);
                cn.ds = new DataSet();
                cn.da.Fill(cn.ds, "UsuariosDesativados");
                return cn.ds.Tables["UsuariosDesativados"];
            }
            catch (Exception)
            {

                throw;
            }
        }

        #endregion
    }
}
