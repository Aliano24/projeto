﻿using ControleDeEstoque.Classe;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControleDeEstoque.Telas
{
    public partial class FrmPrincipal : Form
    {
        Funcionarios funcionarioLogado = new Funcionarios();
        string nivelusu = "";
        public FrmPrincipal(Funcionarios usu)
        {
            InitializeComponent();
            funcionarioLogado = usu;
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void menuUsuario_Click(object sender, EventArgs e)
        {

        }

        private void menuProduto_Click(object sender, EventArgs e)
        {
            frmProdutos Produto = new frmProdutos();
            Produto.ShowDialog();
        }
    }
}
